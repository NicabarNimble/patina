# dashu-base

Common trait definitions for `dashu` crates. See [Docs.rs](https://docs.rs/dashu-base/latest/dashu_base/) for the full documentation.

## License

See the [top-level readme](../README.md).
