//! Debug utilities for types that need a salsa database for debug formatting.

pub mod debug;
pub use crate::debug::{DebugWithDb, helper};
