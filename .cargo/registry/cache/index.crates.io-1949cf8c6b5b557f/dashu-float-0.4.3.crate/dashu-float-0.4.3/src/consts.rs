//! Constants calculation

// to be implemented
