This crate defines a derive macro to introduce a trait
implementation converting values of the attributed type to
syn::DeriveInput. Meant for use with [to-syn-value](https://github.com/mthom/to-syn-value "to-syn-value").
