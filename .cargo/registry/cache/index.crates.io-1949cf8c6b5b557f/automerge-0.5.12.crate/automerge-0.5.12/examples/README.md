# Automerge examples

## Quickstart

```shell
cargo run --example quickstart
```
