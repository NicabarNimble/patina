# Automerge

Automerge is a library of data structures for building collaborative
[local-first](https://www.inkandswitch.com/local-first/) applications. This is
the Rust implementation. See [automerge.org](https://automerge.org/) 
