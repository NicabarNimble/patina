# Salsa item

A salsa item is something that is decorated with a `#[salsa::foo]` macro, like a tracked function or struct.