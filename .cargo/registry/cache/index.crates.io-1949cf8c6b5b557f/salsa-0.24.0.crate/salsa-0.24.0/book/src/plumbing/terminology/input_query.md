# Input query

An *input query* is a [query] whose value is explicitly set by the user. When that value is set, a [durability] can also be provided.

[query]: ./query.md
[durability]: ./durability.md