# Durability

*Durability* is an optimization that we use to avoid checking the [dependencies] of a [query] individually.

[dependencies]: ./dependency.md
[query]: ./query.md
