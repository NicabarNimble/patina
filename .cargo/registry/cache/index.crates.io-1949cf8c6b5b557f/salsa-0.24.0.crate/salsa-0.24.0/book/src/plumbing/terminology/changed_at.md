# Changed at

The *changed at* revision for a [memo] is the [revision] in which that memo's value last changed. Typically, this is the same as the revision in which the [query function] was last executed, but it may be an earlier revision if the memo was [backdated].

[query function]: ./query_function.md
[backdated]: ./backdate.md
[revision]: ./revision.md
[memo]: ./memo.md