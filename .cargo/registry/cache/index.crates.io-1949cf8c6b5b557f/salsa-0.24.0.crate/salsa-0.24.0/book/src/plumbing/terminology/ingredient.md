# Ingredient

An *ingredient* is an individual piece of storage used to create a [salsa item](./salsa_item.md)