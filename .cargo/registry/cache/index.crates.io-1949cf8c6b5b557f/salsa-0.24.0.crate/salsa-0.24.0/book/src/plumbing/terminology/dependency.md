# Dependency

A *dependency* of a [query] Q is some other query Q1 that was invoked as part of computing the value for Q (typically, invoking by Q's [query function]).

[query]: ./query.md
[query function]: ./query_function.md