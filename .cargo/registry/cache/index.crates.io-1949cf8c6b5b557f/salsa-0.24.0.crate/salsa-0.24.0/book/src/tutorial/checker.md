# Defining the checker
