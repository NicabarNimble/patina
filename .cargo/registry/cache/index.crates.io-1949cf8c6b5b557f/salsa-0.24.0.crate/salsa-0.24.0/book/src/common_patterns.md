# Common patterns

This section documents patterns for using Salsa.
