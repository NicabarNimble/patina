#[salsa::interned]
struct Keywords<'db> {}
