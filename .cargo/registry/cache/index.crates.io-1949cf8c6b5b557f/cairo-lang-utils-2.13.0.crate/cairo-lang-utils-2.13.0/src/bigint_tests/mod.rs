#[cfg(feature = "parity-scale-codec")]
mod parity_scale_codec;
#[cfg(feature = "serde")]
mod serde;
