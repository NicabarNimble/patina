pub trait ToDeriveInput {
    fn to_derive_input() -> syn::DeriveInput;
}
