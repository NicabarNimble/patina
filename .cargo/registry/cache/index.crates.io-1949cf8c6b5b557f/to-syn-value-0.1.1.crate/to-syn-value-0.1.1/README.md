Defines the ToDeriveInput trait. Meant for use with [to-syn-value_derive](https://github.com/mthom/to-syn-value_derive "to-syn-value_derive").
