:- use_module(issue2361_m).

:- initialization(gs([(length("a",_),length("ab",_))])).
