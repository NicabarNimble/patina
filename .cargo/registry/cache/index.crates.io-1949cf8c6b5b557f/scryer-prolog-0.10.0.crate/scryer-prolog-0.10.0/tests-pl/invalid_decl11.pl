:- op(10, xf, [example, Var]).
