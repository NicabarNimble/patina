:- initialization((M = user, loader:load_context(M))).
