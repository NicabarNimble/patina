% hello
% line!

a :- b(X).
