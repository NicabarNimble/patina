```trycmd
$ scryer-prolog -f --no-add-history tests-pl/ffi_locals.pl -g halt
With Locals 1
With Locals 2
With Locals 3

```
