test :- write(world), nl.

:- initialization(write(hello)).