:- use_module(library(dcgs)).

d -->
        (   { true } -> []
        ;   { true } -> []
        ).
