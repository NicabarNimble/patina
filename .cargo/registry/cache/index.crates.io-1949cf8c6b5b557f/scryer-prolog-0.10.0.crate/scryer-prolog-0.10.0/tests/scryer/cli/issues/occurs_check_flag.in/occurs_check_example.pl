:- set_prolog_flag(occurs_check, true).

f(X, g(X)).